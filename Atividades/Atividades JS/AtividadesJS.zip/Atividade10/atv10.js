function a1() {
    let açao = document.createElement('section')
    açao.innerHTML = '<p>Clicou no Primeiro Botão</p>'
    document.body.appendChild(açao)
}

function a2() {
    let açao = document.createElement('section')
    açao.innerHTML = '<p>Clicou no Segunda Botão</p>'
    document.body.appendChild(açao)
}

function a3() {
    let açao = document.createElement('section')
    açao.innerHTML = '<p>Clicou no Terceiro Botão</p>'
    document.body.appendChild(açao)
}

function a4() {
    let açao = document.createElement('section')
    açao.innerHTML = '<p>Clicou no Quarto Botão</p>'
    document.body.appendChild(açao)
}